using ExperiencesAPI.Models;
using Microsoft.AspNetCore.Mvc;

namespace ExperiencesAPI.Controllers
{
    [ApiController]
    [Route("Experiences")]
    
    public class ExperienceController : ControllerBase
    {
        private static readonly List<Experience> _experiences = new List<Experience>
        {
            new Experience
            {
                Name = "Hiking",
                Description = "Hiking in the mountains",
                Price = 0
            },
            new Experience
            {
                Name = "Camping",
                Description = "Camping in the woods",
                Price = 50
            },
            new Experience
            {
                Name = "Skiing",
                Description = "Skiing in the mountains",
                Price = 100
            }
        };


        [HttpGet]
        public IEnumerable<Experience> Get()
        {
            return _experiences;
        }
    }
}
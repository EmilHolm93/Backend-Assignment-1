CREATE DATABASE ExperienceShareApp

USE ExperienceShareApp

-- Table for Guests
CREATE TABLE Guests (
    ID INT IDENTITY PRIMARY KEY,
    Name NVARCHAR(100),
    Age INT,
    Phone_Number NVARCHAR(20),
    Person_ID NVARCHAR(100)
);

-- Table for Shared Experiences
CREATE TABLE Shared_Experiences (
    ID INT IDENTITY PRIMARY KEY,
    Name NVARCHAR(100) NOT NULL,
    Date DATE NOT NULL
);

-- Table for Providers
CREATE TABLE Providers (
    ID INT IDENTITY PRIMARY KEY,
    Name NVARCHAR(100) NOT NULL, 
    Business_Addr NVARCHAR(100) NOT NULL,
    CVR_Number INT UNIQUE,
    Phone_Number NVARCHAR(20)
);

-- Table for Experiences
CREATE TABLE Experiences (
    ID INT IDENTITY PRIMARY KEY,
    Name NVARCHAR(100) NOT NULL,
    Price MONEY NOT NULL,
    Provider_ID INT NOT NULL,
    FOREIGN KEY (Provider_ID) REFERENCES Providers(ID) ON DELETE CASCADE
);

-- Table for Discounts
CREATE TABLE Discounts (
    Trigger_Size INT,
    Discount_Percentage DECIMAL(5,2),
    Exp_ID INT NOT NULL,
    PRIMARY KEY (Trigger_Size, Exp_ID),
    FOREIGN KEY (Exp_ID) REFERENCES Experiences(ID) ON DELETE CASCADE
);

-- Table for Suggestions (Guests can suggest Experiences)
CREATE TABLE Suggestions (
    Exp_ID INT NOT NULL,
    Guest_ID INT NOT NULL,
    PRIMARY KEY (Exp_ID, Guest_ID),
    FOREIGN KEY (Exp_ID) REFERENCES Experiences(ID) ON DELETE CASCADE,
    FOREIGN KEY (Guest_ID) REFERENCES Guests(ID) ON DELETE CASCADE
);

-- Table for Joins (Many-to-Many between Shared Experiences and Guests)
CREATE TABLE Joins (
    SharedExp_ID INT NOT NULL,
    Guest_ID INT NOT NULL,
    PRIMARY KEY (SharedExp_ID, Guest_ID),
    FOREIGN KEY (SharedExp_ID) REFERENCES Shared_Experiences(ID) ON DELETE CASCADE,
    FOREIGN KEY (Guest_ID) REFERENCES Guests(ID) ON DELETE CASCADE
);

-- Table for Container (Many-to-Many between Shared Experiences and Experiences)
CREATE TABLE Container (
    Exp_ID INT NOT NULL,
    SharedExp_ID INT NOT NULL,
    PRIMARY KEY (Exp_ID, SharedExp_ID),
    FOREIGN KEY (Exp_ID) REFERENCES Experiences(ID) ON DELETE CASCADE,
    FOREIGN KEY (SharedExp_ID) REFERENCES Shared_Experiences(ID) ON DELETE CASCADE
);

-- Table for Bookings (Guests can book Experiences)
CREATE TABLE Bookings (
    Guest_ID INT NOT NULL,
    Exp_ID INT NOT NULL,
    SharedExp_ID INT NOT NULL,
    PRIMARY KEY (Guest_ID, Exp_ID, SharedExp_ID),
    FOREIGN KEY (Guest_ID) REFERENCES Guests(ID) ON DELETE CASCADE,
    FOREIGN KEY (Exp_ID) REFERENCES Experiences(ID) ON DELETE CASCADE,
    FOREIGN KEY (SharedExp_ID) REFERENCES Shared_Experiences(ID) ON DELETE CASCADE
);


-- Dummy data 

-- Indsæt dummy data i Guests
INSERT INTO Guests (Name, Age, Phone_Number, Person_ID) VALUES
('Joan', 25, '+4511122233', '12345'),
('Suzanne', 30, '+4522233344', '67890'),
('Patrick', 28, '+4533344455', '54321'),
('Anne', 32, '+4544455566', '98765');

-- Indsæt dummy data i Providers
INSERT INTO Providers (Name, Business_Addr, CVR_Number, Phone_Number) VALUES
('Noahs Hotel', 'Finlandsgade 17, Aarhus', 11111114, '+4571555080'),
('Sky Airlines', 'Copenhagen Airport', 22222225, '+4588009900');

-- Indsæt dummy data i Experiences
INSERT INTO Experiences (Name, Price, Provider_ID) VALUES
('Night at Noahs Hotel Single Room', 730.50, 1),
('Night at Noahs Hotel Double Room', 910.99, 1),
('Flight AAR - VIE', 1000.70, 2),
('Vienna Historic Center Walking Tour', 100.00, 2);

-- Indsæt dummy data i Shared Experiences
INSERT INTO Shared_Experiences (Name, Date) VALUES
('Trip to Austria', '2024-07-02'),
('Dinner Downtown', '2024-04-07'),
('Pottery Weekend', '2024-03-22');

-- Indsæt dummy data i Shared Experience Guests
INSERT INTO Joins (SharedExp_ID, Guest_ID) VALUES
(1, 1), (1, 2), (1, 3), (1, 4);

-- Indsæt dummy data i Shared Experience Contain Experiences
INSERT INTO Container (SharedExp_ID, Exp_ID) VALUES
(1, 3), (1, 1), (1, 4);

-- Indsæt dummy data i Suggestions
INSERT INTO Suggestions (Exp_ID, Guest_ID) VALUES
(2, 3),
(3, 4);

-- Indsæt Booking af Experiences i Experience_Bookings 
INSERT INTO Bookings (Guest_ID, Exp_ID, SharedExp_ID)
VALUES
(1, 3, 1),  -- Joan 
(2, 3, 1),  -- Suzzane 
(3, 3, 1),  -- Patrick 
(4, 3, 1),  -- Anne  
(1, 4, 1),  -- Joan tilmelder sig Vienna Historic Center Walking Tour i Trip to Austria
(2, 4, 1),  -- Suzzane tilmelder sig Vienna Historic Center Walking Tour i Trip to Austria
(1, 1, 1),  -- Joan tilmelder sig Night at Noah’s Hotel Single Room i Trip to Austria
(2, 1, 1),
(3, 1, 1),
(4, 1, 1);

-- Indsæt dummy data til Discounts i Experiences
INSERT INTO Discounts (Exp_ID, Trigger_Size, Discount_Percentage) VALUES 
(1, 4, 10.00),   -- Night at Noah's Hotel Single Room: 10% rabat
(1, 50, 20.00),  
(2, 5, 5.00),    -- Night at Noah's Hotel Double Room: 5% rabat
(2, 20, 15.00),  
(3, 10, 10.00),  -- Flight AAR – VIE: 10% rabat
(3, 30, 25.00),  
(4, 2, 5.00),    -- Vienna Historic Center Walking Tour: 5% rabat
(4, 10, 15.00);  

-- QUERYS

-- Query 1: Get the data collected for each experience provider.
SELECT 
 Business_Addr AS 'Address',
 Phone_Number,
 CVR_Number 
FROM Providers WHERE ID = 1

-- Query 2: List the experiences available in the system.
SELECT Name, Price FROM Experiences

-- Query 3: Get the list of shared experiences and their date in the system in descending order
SELECT Name, Date FROM Shared_Experiences ORDER BY Date DESC;

-- Query 4: Get the guests registered for a shared experience.

SELECT G.Name FROM Guests G
JOIN Joins J ON G.ID = J.Guest_ID
JOIN Shared_Experiences SE ON J.SharedExp_ID = SE.ID
WHERE SE.Name = 'Trip to Austria'

-- Query 5: Get the experiences registered for a shared experience.

SELECT E.Name FROM Experiences E
JOIN Container C ON E.ID = C.Exp_ID
JOIN Shared_Experiences SE ON C.SharedExp_ID = SE.ID
WHERE SE.Name = 'Trip to Austria'

-- Query 6:  Get the guests registered for one of the experiences in a shared experience.
SELECT g.Name
FROM Bookings b
JOIN Guests g ON b.Guest_ID = g.ID
JOIN Experiences e ON b.Exp_ID = e.ID
JOIN Shared_Experiences se ON b.SharedExp_ID = se.ID
WHERE e.Name = 'Vienna Historic Center Walking Tour'
AND se.Name = 'Trip to Austria'

-- Noah Hotel Single Room gæster
SELECT g.Name
FROM Bookings b
JOIN Guests g ON b.Guest_ID = g.ID
JOIN Experiences e ON b.Exp_ID = e.ID
JOIN Shared_Experiences se ON b.SharedExp_ID = se.ID
WHERE e.Name = 'Night at Noahs Hotel Single Room'
AND se.Name = 'Trip to Austria'


-- Query 7 Min pris, Max pris og average pris med 4 decimaler
SELECT 
    MIN(Price) AS Min_Price, 
    CAST(AVG(Price) AS DECIMAL(10,4)) AS Avg_Price, 
    MAX(Price) AS Max_Price
FROM Experiences;


-- Query 8 Antal gæster og sum af salg for hver Experience
SELECT 
    e.Name AS Experience, 
    COUNT(eb.Guest_ID) AS Number_of_Guests,
    SUM(CASE 
            WHEN eb.Guest_ID IS NOT NULL THEN e.Price 
            ELSE 0 
        END) AS Sum_Of_Sales
FROM 
    Experiences e
LEFT JOIN 
    Bookings eb 
    ON e.ID = eb.Exp_ID
GROUP BY 
    e.Name, e.Price
ORDER BY 
    CASE 
        WHEN e.Name = 'Night at Noahs Hotel Single Room' THEN 1
        WHEN e.Name = 'Night at Noahs Hotel Double Room' THEN 2
        WHEN e.Name = 'Flight AAR - VIE' THEN 3
        WHEN e.Name = 'Vienna Historic Center Walking Tour' THEN 4
        ELSE 5
    END;

-- Query 9 Oversigt over % Discounts opnået i Experiences
SELECT 
    e.Name AS Experience, 
    COUNT(b.Guest_ID) AS Number_of_Guests, 
    d.Trigger_Size AS Trigger_Size, 
    d.Discount_Percentage AS Discount_Percent, 
    CASE -- Beregning om Discount er opnået på en Experience. Dynamisk data, derfor ikke en attribut i Chen
        WHEN COUNT(b.Guest_ID) >= d.Trigger_Size THEN 'Discount Applied'
        ELSE 'No Discount'
    END AS Discount_Status
FROM Experiences e
LEFT JOIN Bookings b ON e.ID = b.Exp_ID
LEFT JOIN Discounts d ON e.ID = d.Exp_ID
GROUP BY e.Name, d.Trigger_Size, d.Discount_Percentage
ORDER BY e.Name, d.Trigger_Size;
